package com.app.ui;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.Settings;
import android.support.v4.content.FileProvider;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.jar.JarFile;

public class MainActivity extends Activity {

	// ইউনিক ID জেনারেট
	private static int generateViewId() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
			return View.generateViewId();
		} else {
			return (int) (System.currentTimeMillis() & 0xFFFF);
		}
	}

	int[] appIcons = { R.drawable.app, R.drawable.fps, R.drawable.Notify, R.drawable.hd, R.drawable.studio, R.drawable.calculator,
			R.drawable.profile };

	String[] appNames = { "App Manager", "FPS Monitor", "NotifyMe", "Hidden-Settings", "Android-IDE", "Calculator", "My-Profile" };

	private Map<String, String> appPackages = new HashMap<String, String>() {
		{
			put("App Manager", "com.app.manager");
			put("FPS Monitor", "com.view.fps");
			put("NotifyMe", "com.app.notify");
			put("Hidden-Settings", "com.hidden.settings");
			put("Android-IDE", "com.tyron.code");
			put("Calculator", "com.msi.calculator");
			put("My-Profile", "com.sirajul.profile");
		}
	};

	String[] downloadLinks = {
			"https://github.com/MSI-Sirajul/App-Manager/releases/download/App-Manager/App_Manager-v1.0_Release.apk",
			"https://github.com/MSI-Sirajul/FPS-Monitor/releases/download/FPS-AND-RAM/FPS_Monitor_v5.2.5-debug.apk",
			"https://github.com/MSI-Sirajul/NotifyMe/releases/download/Sms-forwarder/NotifyMe_New_Release.apk",
			"https://github.com/MSI-Sirajul/Hidden-Settings/releases/download/Hidden-Settings/Hidden-Setting-v4.6.1_letest.apk",
			"https://github.com/MSI-Sirajul/Android-IDE/releases/download/Android-IDE/Android.IDE_v0.2.9.Sirajul26.20.apk",
			"https://github.com/MSI-Sirajul/Calculator/releases/download/Calculator_1.7/Calculator_V1.7_Released.apk",
			"https://github.com/MSI-Sirajul/WebView-Profile/releases/download/WebView/Profile_release.apk" };

	private Map<Long, String> downloadMap = new HashMap<>();
	private Map<Long, ProgressDialog> progressDialogs = new HashMap<>();

	private int[] slideImages = { R.drawable.image1, R.drawable.image2 };
	private int currentSlide = 0;
	private Handler handler = new Handler();
	private ImageView slideImageView;
	private LinearLayout dotsLayout;
	private float initialX;
	private int TOOLBAR_ID;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		TOOLBAR_ID = generateViewId();

		// টাইটেল বার সম্পূর্ণ রিমুভ
		if (getActionBar() != null) {
			getActionBar().hide();
		}

		// UI তৈরি
		createCompleteUI();
		checkPermissions();
		registerDownloadReceiver();
	}

	// স্ট্যাটাস বার উচ্চতা
	private int getStatusBarHeight() {
		int height = 0;
		int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
		if (resourceId > 0) {
			height = getResources().getDimensionPixelSize(resourceId);
		}
		return height;
	}

	// প্রধান UI তৈরি
	private void createCompleteUI() {
		// 1. মূল কন্টেইনার (RelativeLayout)
		RelativeLayout rootLayout = new RelativeLayout(this);
		rootLayout.setLayoutParams(
				new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
		rootLayout.setBackgroundColor(Color.parseColor("#D5F7FF"));

		// টাইটেল বার স্ট্যাটাস বারের সাথে যুক্ত করা
		int statusBarHeight = getStatusBarHeight();
		rootLayout.setPadding(0, 0, 0, 0); // কোন প্যাডিং নয়

		// 2. কাস্টম টাইটেল বার তৈরি
		RelativeLayout toolBar = new RelativeLayout(this);
		toolBar.setId(TOOLBAR_ID);
		RelativeLayout.LayoutParams toolbarParams = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
				dpToPx(65) + statusBarHeight // স্ট্যাটাস বারের উচ্চতা যোগ
		);
		toolBar.setLayoutParams(toolbarParams);
		toolBar.setPadding(0, statusBarHeight, 0, 0); // টাইটেল বার কন্টেন্ট স্ট্যাটাস বার নিচে শুরু
		toolBar.setBackgroundColor(Color.parseColor("#00B1FF"));

		// টাইটেল টেক্সট
		TextView titleText = new TextView(this);
		titleText.setText("My Apps Store");
		titleText.setTextSize(20);
		titleText.setTextColor(Color.WHITE);
		titleText.setTypeface(Typeface.DEFAULT_BOLD);
		titleText.setGravity(Gravity.CENTER_VERTICAL);

		RelativeLayout.LayoutParams titleParams = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
				ViewGroup.LayoutParams.MATCH_PARENT);
		titleParams.setMargins(dpToPx(20), 0, 0, 0);
		titleParams.addRule(RelativeLayout.CENTER_VERTICAL);
		titleText.setLayoutParams(titleParams);

		// সেটিংস বাটন
		ImageView settingsBtn = new ImageView(this);
		settingsBtn.setImageResource(R.drawable.settings_ic);
		settingsBtn.setColorFilter(Color.LTGRAY);
		settingsBtn.setOnClickListener(v -> showNetworkSettings());

		RelativeLayout.LayoutParams settingsParams = new RelativeLayout.LayoutParams(dpToPx(30), dpToPx(30));
		settingsParams.setMargins(0, 0, dpToPx(20), 0);
		settingsParams.addRule(RelativeLayout.ALIGN_PARENT_END);
		settingsParams.addRule(RelativeLayout.CENTER_VERTICAL);
		settingsBtn.setLayoutParams(settingsParams);

		toolBar.addView(titleText);
		toolBar.addView(settingsBtn);
		rootLayout.addView(toolBar);

		// 3. মূল কন্টেন্ট রিসিভার (টুলবারের নিচে)
		RelativeLayout contentArea = new RelativeLayout(this);
		RelativeLayout.LayoutParams contentParams = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
				ViewGroup.LayoutParams.MATCH_PARENT);
		contentParams.setMargins(0, 0, 0, 0);
		contentParams.addRule(RelativeLayout.BELOW, TOOLBAR_ID);
		rootLayout.addView(contentArea, contentParams);

		// 4. মূল কন্টেন্ট লিনিয়ার লেআউট
		LinearLayout mainContent = new LinearLayout(this);
		mainContent.setOrientation(LinearLayout.VERTICAL);
		mainContent.setLayoutParams(
				new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
		contentArea.addView(mainContent);

		// 5. স্লাইড কন্টেইনার (বর্ডার সহ)
		FrameLayout slideContainer = new FrameLayout(this);
		LinearLayout.LayoutParams slideParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
				dpToPx(200));
		// গ্রিড ভিউয়ের মতই মার্জিন সেট করা হয়েছে
		slideParams.setMargins(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16));

		// স্লাইড ব্যাকগ্রাউন্ড সেট (বর্ডার)
		slideContainer.setBackground(createRoundedBackground(Color.WHITE, 12));

		slideImageView = new ImageView(this);
		FrameLayout.LayoutParams slideImageParams = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
				ViewGroup.LayoutParams.MATCH_PARENT);
		slideImageParams.setMargins(dpToPx(2), dpToPx(2), dpToPx(2), dpToPx(2)); // ভিতরের ম্যাজিক
		slideImageView.setLayoutParams(slideImageParams);
		slideImageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
		slideImageView.setImageResource(slideImages[0]);
		slideImageView.setBackground(createRoundedBackground(Color.TRANSPARENT, 10));

		dotsLayout = new LinearLayout(this);
		dotsLayout.setGravity(Gravity.CENTER);

		FrameLayout.LayoutParams dotsParams = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
				ViewGroup.LayoutParams.WRAP_CONTENT);
		dotsParams.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
		dotsParams.bottomMargin = dpToPx(16);
		dotsLayout.setLayoutParams(dotsParams);

		for (int i = 0; i < slideImages.length; i++) {
			ImageView dot = new ImageView(this);
			dot.setImageResource(i == 0 ? R.drawable.dot_selected : R.drawable.dot_unselected);

			LinearLayout.LayoutParams dotParams = new LinearLayout.LayoutParams(dpToPx(10), dpToPx(10));
			dotParams.setMargins(dpToPx(5), 0, dpToPx(5), 0);
			dot.setLayoutParams(dotParams);
			dotsLayout.addView(dot);
		}

		slideContainer.addView(slideImageView);
		slideContainer.addView(dotsLayout);

		// সোয়াইপ জেসচার
		slideContainer.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()) {
				case MotionEvent.ACTION_DOWN:
					initialX = event.getX();
					break;
				case MotionEvent.ACTION_UP:
					float deltaX = event.getX() - initialX;
					if (Math.abs(deltaX) > dpToPx(50)) {
						if (deltaX > 0) {
							showSlide(currentSlide - 1);
						} else {
							showSlide(currentSlide + 1);
						}
					}
					break;
				}
				return true;
			}
		});

		// 6. অ্যাপ গ্রিড কন্টেইনার (স্লাইডের মতই মার্জিন)
		LinearLayout gridContainer = new LinearLayout(this);
		LinearLayout.LayoutParams gridParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0 // ওজন দ্বারা নিয়ন্ত্রিত হবে
		);
		gridParams.weight = 1; // অবশিষ্ট স্থান নেয়
		gridParams.setMargins(dpToPx(16), 0, dpToPx(16), dpToPx(16)); // স্লাইডের মত মার্জিন

		gridContainer.setBackground(createRoundedBackground(Color.WHITE, 12));

		GridView gridView = new GridView(this);
		gridView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
				ViewGroup.LayoutParams.MATCH_PARENT));
		gridView.setNumColumns(2);
		gridView.setAdapter(new AppAdapter());
		gridView.setVerticalSpacing(dpToPx(16));
		gridView.setHorizontalSpacing(dpToPx(16));
		gridView.setPadding(dpToPx(10), dpToPx(10), dpToPx(10), dpToPx(10));

		gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				String appName = appNames[position];
				String packageName = appPackages.get(appName);

				if (isAppInstalled(packageName)) {
					launchApp(packageName);
				} else {
					Toast.makeText(MainActivity.this, appName + " not installed, downloading...", Toast.LENGTH_SHORT)
							.show();
					startDownload(downloadLinks[position], appName);
				}
			}
		});

		gridContainer.addView(gridView);

		// সব কম্পোনেন্ট যোগ
		mainContent.addView(slideContainer, slideParams);
		mainContent.addView(gridContainer, gridParams);

		// কন্টেন্ট সেট
		setContentView(rootLayout);

		// স্লাইডশো শুরু
		startSlideshow();

		// স্ট্যাটাস বার রং টাইটেল বারের সাথে মিলিয়ে সেট করা
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
			getWindow().setStatusBarColor(Color.parseColor("#00B1FF"));
		}
	}

	// স্লাইড পরিবর্তন
	private void showSlide(int position) {
		if (position < 0)
			position = slideImages.length - 1;
		if (position >= slideImages.length)
			position = 0;

		currentSlide = position;
		slideImageView.setImageResource(slideImages[position]);

		for (int i = 0; i < dotsLayout.getChildCount(); i++) {
			ImageView dot = (ImageView) dotsLayout.getChildAt(i);
			dot.setImageResource(i == position ? R.drawable.dot_selected : R.drawable.dot_unselected);
		}
	}

	// অটো স্লাইডশো
	private void startSlideshow() {
		handler.postDelayed(new Runnable() {
			@Override
			public void run() {
				showSlide(currentSlide + 1);
				handler.postDelayed(this, 3000);
			}
		}, 3000);
	}

	// অ্যাপ ইন্সটল কিনা চেক
	private boolean isAppInstalled(String packageName) {
		try {
			getPackageManager().getPackageInfo(packageName, PackageManager.GET_ACTIVITIES);
			return true;
		} catch (PackageManager.NameNotFoundException e) {
			return false;
		}
	}

	// অ্যাপ চালু
	private void launchApp(String packageName) {
		try {
			Intent launchIntent = getPackageManager().getLaunchIntentForPackage(packageName);
			startActivity(launchIntent);
		} catch (Exception e) {
			Toast.makeText(this, "Error launching app", Toast.LENGTH_SHORT).show();
		}
	}

	// ডাউনলোড শুরু
	private void startDownload(String url, String appName) {
		DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
		request.setTitle("Downloading " + appName);
		request.setDescription("Please wait...");
		request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, appName + ".apk");
		request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE);

		applyNetworkSettings(request);

		DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
		long downloadId = manager.enqueue(request);

		ProgressDialog progressDialog = new ProgressDialog(this);
		progressDialog.setTitle("Downloading");
		progressDialog.setMessage(appName + " (0%)");
		progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
		progressDialog.setMax(100);
		progressDialog.setCancelable(true);
		progressDialog.setOnCancelListener(dialog -> {
			manager.remove(downloadId);
			downloadMap.remove(downloadId);
			progressDialogs.remove(downloadId);
		});
		progressDialog.show();

		downloadMap.put(downloadId, appName);
		progressDialogs.put(downloadId, progressDialog);
	}

	// নেটওয়ার্ক সেটিংস প্রয়োগ
	private void applyNetworkSettings(DownloadManager.Request request) {
		SharedPreferences prefs = getSharedPreferences("NETWORK_PREFS", MODE_PRIVATE);
		boolean wifiOnly = prefs.getBoolean("WIFI_ONLY", false);
		boolean lowDataMode = prefs.getBoolean("LOW_DATA", false);

		request.setAllowedOverMetered(!wifiOnly);

		if (lowDataMode) {
			request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_HIDDEN);
		}
	}

	// নেটওয়ার্ক সেটিংস ডায়ালগ
	private void showNetworkSettings() {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("Network Settings");

		LinearLayout layout = new LinearLayout(this);
		layout.setOrientation(LinearLayout.VERTICAL);
		layout.setPadding(dpToPx(24), dpToPx(24), dpToPx(24), dpToPx(24));

		SharedPreferences prefs = getSharedPreferences("NETWORK_PREFS", MODE_PRIVATE);

		CheckBox wifiOnlyCB = createCheckBox("Download only on Wi-Fi", prefs.getBoolean("WIFI_ONLY", false));

		CheckBox lowDataCB = createCheckBox("Low data mode (hide notifications)", prefs.getBoolean("LOW_DATA", false));

		layout.addView(wifiOnlyCB);
		layout.addView(lowDataCB);
		builder.setView(layout);

		builder.setPositiveButton("Save", (dialog, which) -> {
			saveNetworkSettings(wifiOnlyCB.isChecked(), lowDataCB.isChecked());
			dialog.dismiss();
		});

		builder.setNegativeButton("Cancel", null);
		builder.show();
	}

	// চেকবক্স তৈরি
	private CheckBox createCheckBox(String text, boolean checked) {
		CheckBox cb = new CheckBox(this);
		cb.setText(text);
		cb.setChecked(checked);

		LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
				ViewGroup.LayoutParams.WRAP_CONTENT);
		params.bottomMargin = dpToPx(16);
		cb.setLayoutParams(params);

		return cb;
	}

	// নেটওয়ার্ক সেটিংস সেভ
	private void saveNetworkSettings(boolean wifiOnly, boolean lowData) {
		SharedPreferences.Editor editor = getSharedPreferences("NETWORK_PREFS", MODE_PRIVATE).edit();

		editor.putBoolean("WIFI_ONLY", wifiOnly);
		editor.putBoolean("LOW_DATA", lowData);
		editor.apply();

		Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show();
	}

	// ডাউনলোড সম্পূর্ণ রিসিভার
	private final BroadcastReceiver downloadReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {
			long id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
			String appName = downloadMap.remove(id);
			ProgressDialog dialog = progressDialogs.remove(id);

			if (dialog != null && dialog.isShowing()) {
				dialog.dismiss();
			}

			if (appName != null) {
				DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
				Cursor cursor = manager.query(new DownloadManager.Query().setFilterById(id));

				if (cursor.moveToFirst()) {
					String uriString = cursor.getString(cursor.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI));
					if (uriString != null) {
						File file = new File(Uri.parse(uriString).getPath());
						if (validateApk(file)) {
							installApk(file);
						} else {
							showCorruptionDialog(appName);
						}
					}
				}
				cursor.close();
			}
		}
	};

	// APK ভ্যালিডেশন
	private boolean validateApk(File file) {
		try {
			new JarFile(file).close();
			PackageManager pm = getPackageManager();
			PackageInfo info = pm.getPackageArchiveInfo(file.getPath(), 0);
			return info != null;
		} catch (Exception e) {
			return false;
		}
	}

	// APK ইন্সটল
	private void installApk(File file) {
		try {
			Intent install = new Intent(Intent.ACTION_VIEW);

			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
				Uri apkUri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".provider", file);
				install.setDataAndType(apkUri, "application/vnd.android.package-archive");
				install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
			} else {
				install.setDataAndType(Uri.fromFile(file), "application/vnd.android.package-archive");
			}

			install.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			startActivity(install);
		} catch (Exception e) {
			Toast.makeText(this, "Install failed", Toast.LENGTH_LONG).show();
		}
	}

	// দুর্নীতিগ্রস্থ ফাইল ডায়ালগ
	private void showCorruptionDialog(String appName) {
		new AlertDialog.Builder(this).setTitle("Download Error")
				.setMessage("The downloaded file is corrupt. Retry download?")
				.setPositiveButton("Retry", (dialog, which) -> {
					int position = Arrays.asList(appNames).indexOf(appName);
					if (position >= 0) {
						startDownload(downloadLinks[position], appName);
					}
				}).setNegativeButton("Cancel", null).show();
	}

	// রাউন্ডেড ব্যাকগ্রাউন্ড তৈরি
	private GradientDrawable createRoundedBackground(int color, int radius) {
		GradientDrawable shape = new GradientDrawable();
		shape.setShape(GradientDrawable.RECTANGLE);
		shape.setCornerRadius(dpToPx(radius));
		shape.setColor(color);
		shape.setStroke(dpToPx(1), Color.parseColor("#CCCCCC")); // বর্ডার পুরুত্ব ও রং
		return shape;
	}

	// ডিপি থেকে পিক্সেল
	private int dpToPx(int dp) {
		return Math.round(dp * getResources().getDisplayMetrics().density);
	}

	private void checkPermissions() {
		// অ্যান্ড্রয়েড মার্শম্যালো (API 23) থেকে পারমিশন সিস্টেম
		if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
			if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				// পারমিশন অনুরোধ
				String[] permissions = { Manifest.permission.WRITE_EXTERNAL_STORAGE };
				requestPermissions(permissions, 101);
			}
		}
	}

	// পারমিশন রেজাল্ট
	@Override
	public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
		super.onRequestPermissionsResult(code, perms, results);
		if (code == 101 && results.length > 0 && results[0] != PackageManager.PERMISSION_GRANTED) {
			Toast.makeText(this, "Permission required for downloads", Toast.LENGTH_LONG).show();
		}
	}

	// ডাউনলোড রিসিভার রেজিস্টার
	private void registerDownloadReceiver() {
		registerReceiver(downloadReceiver, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));

		handler.post(new ProgressUpdater());
	}

	// প্রগ্রেস আপডেটার
	private class ProgressUpdater implements Runnable {
		@Override
		public void run() {
			DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);

			for (Long id : new ArrayList<>(downloadMap.keySet())) {
				DownloadManager.Query query = new DownloadManager.Query().setFilterById(id);
				try (Cursor cursor = manager.query(query)) {
					if (cursor.moveToFirst()) {
						int status = cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_STATUS));
						if (status == DownloadManager.STATUS_RUNNING) {
							int downloaded = cursor
									.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
							int total = cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));

							if (total > 0) {
								int progress = (int) ((downloaded * 100L) / total);
								ProgressDialog dialog = progressDialogs.get(id);
								if (dialog != null) {
									dialog.setProgress(progress);
									dialog.setMessage(downloadMap.get(id) + " (" + progress + "%)");
								}
							}
						}
					}
				}
			}
			handler.postDelayed(this, 1000);
		}
	}

	// অ্যাপ অ্যাডাপ্টার
	private class AppAdapter extends BaseAdapter {
		@Override
		public int getCount() {
			return appIcons.length;
		}

		@Override
		public Object getItem(int position) {
			return null;
		}

		@Override
		public long getItemId(int position) {
			return 0;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			LinearLayout appLayout = new LinearLayout(MainActivity.this);
			appLayout.setOrientation(LinearLayout.VERTICAL);
			appLayout.setGravity(Gravity.CENTER);
			appLayout.setPadding(dpToPx(12), dpToPx(12), dpToPx(12), dpToPx(12));
			appLayout.setBackground(createRoundedBackground(0xFFFAFAFA, 8));

			ImageView icon = new ImageView(MainActivity.this);
			icon.setImageResource(appIcons[position]);
			icon.setLayoutParams(new LinearLayout.LayoutParams(dpToPx(60), dpToPx(60)));

			TextView name = new TextView(MainActivity.this);
			name.setText(appNames[position]);
			name.setTextColor(Color.BLACK);
			name.setTextSize(14);
			name.setGravity(Gravity.CENTER);

			appLayout.addView(icon);
			appLayout.addView(name);
			return appLayout;
		}
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		try {
			unregisterReceiver(downloadReceiver);
		} catch (Exception ignored) {
		}
		handler.removeCallbacksAndMessages(null);
	}
}